﻿using System;

namespace P03_SalesDatabase
{
    public class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
