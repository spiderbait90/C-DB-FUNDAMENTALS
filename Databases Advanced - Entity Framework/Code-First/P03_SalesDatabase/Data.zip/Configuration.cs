﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string ConectionsString = @"Server=LAPTOP-5INT06OK\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
